#!/bin/sh
while sleep 1;
do
python ./bot.py
done